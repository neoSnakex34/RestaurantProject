package viewPackage;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.ResourceBundle.Control;
import java.io.ObjectInputStream;

public abstract class MealHandler {
	
	//to test
	//private Meal m1 = new Meal("pizza", 10);
	public static ArrayList<Meal> meals = new ArrayList<>();
	
	public static void writeOb(Meal m1) {
	try {
		FileOutputStream out = new FileOutputStream("menu.txt");
		ObjectOutputStream toWrite = new ObjectOutputStream(out);
		
		toWrite.writeObject(m1);
		toWrite.close();
	}
	catch (Exception ex){
		ex.printStackTrace();
	}
	}
	
	
	//lettore;
	//TODO manage to give String as a return type probably 
	//TODO think of using generics instead
	
	public static void readObjs(){
		int controlState = 0;
		
		try {
			FileInputStream in = new FileInputStream("menu.txt");
			ObjectInputStream toRead = new ObjectInputStream(in);
			
			while(controlState == 0) {
				
				try {
					meals.add((Meal) toRead.readObject());
				}
				catch (EOFException e) {
					controlState = -1;
					// TODO: handle exception
				}
				
			}
			
			
			for(Meal m:meals) {
				System.out.println(m);
			}
			    
		//Meal m1 = (Meal) toRead.readObject();
			}
			
			catch (Exception e) {
				
				// TODO: handle exception
			}
			
		

	
}
	}
